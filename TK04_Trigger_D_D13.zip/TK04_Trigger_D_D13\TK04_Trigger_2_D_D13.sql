-- =========================================================================================
-- Trigger 2: Pencegahan transfer miles melebihi saldo dan pencatatan log riwayat transfer miles
-- Kelas: D
-- Kelompok: D13
-- =========================================================================================

CREATE OR REPLACE FUNCTION cek_dan_catat_transfer_miles()
RETURNS TRIGGER AS $$
DECLARE
    saldo_pengirim INT;
BEGIN
    -- Mengambil saldo award_miles pengirim (email_member_1)
    SELECT award_miles INTO saldo_pengirim
    FROM MEMBER
    WHERE email = NEW.email_member_1;

    -- Validasi: Jika saldo kurang dari jumlah transfer, batalkan transaksi
    IF saldo_pengirim < NEW.jumlah THEN
        RAISE EXCEPTION 'ERROR: Saldo award miles tidak mencukupi. Saldo Anda saat ini: % miles, jumlah transfer: % miles.', saldo_pengirim, NEW.jumlah;
    END IF;

    -- Update saldo pengirim (mengurangi award_miles)
    UPDATE MEMBER
    SET award_miles = award_miles - NEW.jumlah
    WHERE email = NEW.email_member_1;

    -- Update saldo penerima (menambah award_miles dan total_miles)
    UPDATE MEMBER
    SET award_miles = award_miles + NEW.jumlah,
        total_miles = total_miles + NEW.jumlah
    WHERE email = NEW.email_member_2;

    -- Set timestamp secara otomatis jika kosong
    IF NEW.timestamp IS NULL THEN
        NEW.timestamp := CURRENT_TIMESTAMP;
    END IF;

    -- Menampilkan pesan sukses
    RAISE NOTICE 'SUKSES: Transfer % miles dari "%" ke "%" berhasil dicatat.', NEW.jumlah, NEW.email_member_1, NEW.email_member_2;

    -- Membiarkan INSERT pada tabel TRANSFER dilanjutkan
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_transfer_miles
BEFORE INSERT ON TRANSFER
FOR EACH ROW
EXECUTE FUNCTION cek_dan_catat_transfer_miles();
